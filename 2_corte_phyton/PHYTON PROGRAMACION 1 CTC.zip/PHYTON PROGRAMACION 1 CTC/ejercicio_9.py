#escribir un programa que me permita recorrer matrices
#me imprima el numero de filas y columnas, y los 
#elementos de la matriz

matrizuno = [[1,2,3,4], [5,6,7,8], [9,10,11,12]]
matrizdos = [[1,2,3], [4,5,5], [7,8,9]]

#procesamiento
for fila in matrizuno:
    print(fila)
    for elemento in fila:
        print(elemento)

for fila in matrizdos: #recorrido de las filas de la matrizdos
    for columna in fila: #recorrido de las columnas de la matrizdos
        print(columna, end="-")
    print()

#numeros de filas y columnas
nfilasuno = len(matrizuno)
print("el matriz uno tiene ", nfilasuno, " filas")
nfilasdos = len(matrizdos)
print("el matriz dos tiene ", nfilasdos, "filas")
ncolumnasuno = len(matrizuno[0])
print("el matriz uno tiene ", ncolumnasuno, "columnas")
ncolumnasdos = len(matrizdos[0])
print("la matriz dos tiene ", ncolumnasdos, "columnas")




