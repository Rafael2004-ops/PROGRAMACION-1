#Realizar un programa que me muestre la tabla de multiplicar 
# hasta el numero 10 , dado un número ingresado por teclado

#Datos Entrada
num = int(input("Ingresar el número: "))

#Procesamiento
for i in range(1,11,1):
    #Datos de salida
    print(f"num*{i}=", num*i)