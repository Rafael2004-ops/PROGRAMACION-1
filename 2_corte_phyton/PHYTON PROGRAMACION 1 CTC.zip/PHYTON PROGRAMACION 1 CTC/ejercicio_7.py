#arreglo lista de nombre de diferentes nmotas
#datos de entrada

personas=['rafael','saray','ruben','DARIO']
notas=[4.8,4.3,3.5,5]

for persona in personas:
    print(f'nombre: {persona}')

for resultado, persona in zip(notas, personas):
    print(f'el alumno {persona} obtuvo una puntuacion de {notas}')

    