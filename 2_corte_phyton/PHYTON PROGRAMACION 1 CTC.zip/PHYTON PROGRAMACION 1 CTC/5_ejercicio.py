#realizar un arreglo que me permite ingresar numeros
arreglo=[]
#arreglo_uno=list()
# arreglo_dos=[1,2,3,4,5]

arreglo.append(1)
arreglo.append(3)
arreglo.append(4)

numero=int(input("ingresar numero: "))

while numero > 0:
    arreglo.append(numero)
    numero = int(input("ingresar numero al arreglo"))

print(arreglo)