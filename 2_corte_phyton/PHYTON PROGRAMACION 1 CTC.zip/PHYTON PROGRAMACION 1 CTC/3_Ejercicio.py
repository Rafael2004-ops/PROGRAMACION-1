#Escribir un programa que me permita ingresar un número
#y me determina si es primo.

#Datos de entrada
numero = int(input("Ingresar un número "))
contador = 0

#Procesamiento
for i in range(1,numero+1):
    if numero % i == 0:
        contador = contador+1

#Salida
if contador == 2:
    print("El número ingresado es primo")
else:
    print("El numero ingresado NO es primo")