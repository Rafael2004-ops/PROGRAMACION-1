#escribir  un programa que me imprima la siguiente matriz
#matriz=[[1,2][3,4]]


matriz =[[1,2],[3,4]]

print(f'consultar posicion [1,2] = {matriz[0][1]}')

#procesamiento
for filas in matriz:
    for columnas in filas:
        print(columnas)

