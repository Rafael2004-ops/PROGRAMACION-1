# Definición del arreglo 'datos'
datos = [1, 2, True, "hola", 58, False]

# Definición del arreglo 'informacion'
informacion = [1, 2, True, "hola", 58, False]  # Corregimos true y false

# Procesamiento: Eliminamos elementos de las listas
datos.pop(2)  # Elimina el elemento en la posición 2 (True)
datos.pop(0)  # Elimina el elemento en la posición 0 (1)

# Eliminamos elementos específicos de 'informacion'
informacion.remove(1)  # Elimina la primera aparición del número 1
informacion.remove(2)  # Elimina la primera aparición del número 2

# Datos de salida
print("Datos:", datos)
print("Información:", informacion)
