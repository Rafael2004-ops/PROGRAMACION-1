#Escribir un programa que me pida números hasta que ingrese un cero,
#Debe hallar la suma, la cantidad y la media de los números ingresados

#Datos entrada
num = int(input("Ingrese un número: "))
acumulador = 0
contador = 0

#Procesamiento
while(num>0):
    acumulador = acumulador+num
    contador = contador+1
    num = int(input("Ingrese un número: "))
    

#Datos de salida
print("La suma es: ", acumulador)
print("La cantidad de números es: ", contador)
print("La media de los números es: ", (acumulador/contador))