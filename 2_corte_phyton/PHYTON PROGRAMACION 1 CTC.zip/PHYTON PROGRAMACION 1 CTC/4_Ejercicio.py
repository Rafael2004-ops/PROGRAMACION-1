#Realizar un programa que me calcule la suma de los divisores de cada número
#ingresado por teclado, el programa termina cuando se ingresa un número que
#sea negativo
#4=>1,2,4 => suma = 7
#8=>1,2,4,8 => suma = 15

#Datos de Entrada
num = int(input("Ingresar número por teclado "))

#Procesamiento
while num > 0:
    suma = 0
    for i in range(1,num+1):
        if num%i==0:
            suma = suma+i
    
#Datos de Salida
    print(f"La suma de los divisores del número {num} =", suma)
    num = int(input("Ingresar número por teclado "))
